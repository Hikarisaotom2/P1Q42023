package clase16_enero_2024;

/**
 *
 * @author Clau
 */
public class Clase16_enero_2024 {
    public static void main(String[] args) {
    /*
    Las declaración de variables en java sigue el siguiente patron: 
    tipoDeDato nombreVariable;
    tipoDeDato nombreVariable = valorInicial;
*/
    //promedio de calificaciones 
   // promedioDeCalificaciones camelCase
   // promedio_de_calificaciones snake_case
   // PromedioDeCalificaciones PascalCase
    
    int edadPersona = 5;
    double promedioNotas = 5.5;
    float valoresDeci= 0;
    long numeroLong = 9;
    short numeroShort = 9;
    byte numeroByte = 5;
    char inicial = 'c';
    boolean valorBool=true;
    
    //Consola
     System.out.println("Hola mundo salto de linea");
    System.out.print("Hola Mundo!!!!");
   
    
    
    
    
    }
    
}
